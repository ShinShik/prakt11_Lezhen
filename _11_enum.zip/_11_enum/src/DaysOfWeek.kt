enum class DaysOfWeek(val day: String, val number: Int)
{
    MONDAY("Monday", 1),
    TUESDAY("Tuesday", 2),
    WEDNESDAY("Wednesday", 3),
    THURSDAY("Thursday", 4),
    FRIDAY("Friday", 5),
    SATURDAY("Saturday", 6),
    SUNDAY("Sunday", 7);
    fun printDays(days: DaysOfWeek)
    {
        println("Day of the week: ${days.day} (${days.number})")
    }
    fun printAllDays(){
        for (i in 1..7 ){
            when(i){
                1->printDays(MONDAY)
                2->printDays(TUESDAY)
                3->printDays(WEDNESDAY)
                4->printDays(THURSDAY)
                5->printDays(FRIDAY)
                6->printDays(SATURDAY)
                7->printDays(SUNDAY)
            }
        }
    }
    fun nextDay(day:DaysOfWeek){
        val x = day.number+1
        when(x){
            2->printDays(TUESDAY)
            3->printDays(WEDNESDAY)
            4->printDays(THURSDAY)
            5->printDays(FRIDAY)
            6->printDays(SATURDAY)
            7->printDays(SUNDAY)
            8->printDays(MONDAY)
        }
    }
    fun lastDay(day:DaysOfWeek){
        val x = day.number-1
        when(x){
            0->printDays(SUNDAY)
            1->printDays(MONDAY)
            2->printDays(TUESDAY)
            3->printDays(WEDNESDAY)
            4->printDays(THURSDAY)
            5->printDays(FRIDAY)
            6->printDays(SATURDAY)
        }
    }
}



