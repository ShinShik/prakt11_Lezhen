fun main() {
    var day1=DaysOfWeek.SUNDAY
    day1.printDays(DaysOfWeek.MONDAY)
    day1.printAllDays()
    day1.nextDay(DaysOfWeek.SUNDAY)
    day1.lastDay(DaysOfWeek.SUNDAY)

    var colo1=Colors.RED
    colo1.printColors(Colors.RED)
    colo1.printAllColors()
    colo1.colorInRainbow(Colors.YELLOW)
    colo1.colorRGB(Colors.GREEN)
}