enum class Colors(val color: String, val number: Int)
{
    RED("Red", 1),
    GREEN("Green", 2),
    BLUE("Blue", 3),
    YELLOW("Yellow", 4);
    fun printColors(colors: Colors)
    {
        println("Color: ${colors.color} (${colors.number})")
    }
    fun printAllColors(){
        for (i in 1..4 ){
            when(i){
                1->printColors(RED)
                2->printColors(GREEN)
                3->printColors(BLUE)
                4->printColors(YELLOW)
                else ->println("ERROR")
            }
        }
    }
    fun colorInRainbow(color:Colors){
        when(color){
            RED -> println("1")
            GREEN -> println("4")
            BLUE -> println("6")
            YELLOW -> println("3")
        }
    }
    fun colorRGB(color:Colors){
        when(color){
            RED -> println("FF0000")
            GREEN -> println("#008000")
            BLUE -> println("#0000FF")
            YELLOW -> println("#FFFF00")
        }
    }
}